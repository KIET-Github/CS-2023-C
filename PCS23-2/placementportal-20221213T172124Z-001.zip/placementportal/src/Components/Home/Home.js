import React from "react";
import Maincontent from '../MainContent/maincontent.js';

import './Home.css';
export default function Home() {
  return (
    <Maincontent/>
  );
}
