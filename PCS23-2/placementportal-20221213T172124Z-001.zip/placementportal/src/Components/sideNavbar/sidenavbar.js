import React from "react";
import "./sideNavbar.css";

export default function  Sidenaavbar({setValue}) {
  return (
    <div className="sideNavbar">
      
      <div className="sidebar">
        <div className="sidebar_inner">
          <ul>
            <li>
              <a href="/" onClick={()=>{setValue("maincon");console.log("maincon")}}>
                <span class="icon">
                  <i className="fa fa-qrcode"></i>
                </span>
                <span className="text" >Home</span>
              </a>
            </li>

            <li>
              <a href="/" onClick={()=>{setValue("about")}} >
                <span className="icon">
                  <i className="fa fa-link"></i>
                </span>
                <span className="text">About</span>
              </a>
            </li>
            <li>
              <a href="/" onClick={()=>{setValue("student");}}>
                <span className="icon">
                  <i className="fa fa-eye"></i>
                </span>
                <span className="text">Student</span>
              </a>
            </li>
            <li>
              <a href="/" onClick={ ()=>{ setValue("comp")}}>
                <span className="icon">
                  <i className="fa fa-book"></i>
                </span>
                <span className="text">Company</span>
              </a>
            </li>
            <li>
              <a href="/" onClick={()=>{setValue("recruitment") }}>
                <span className="icon">
                  <i className="fa fa-question-circle"></i>
                </span>
                <span className="text">Recruitment</span>
              </a>
            </li>
            <li>
              <a href="/" onClick={()=>{setValue("alumni");}}>
                <span className="icon">
                  <i className="fa fa-pen"></i>
                </span>
                <span className="text">Alumni</span>
              </a>
            </li>
            <li>
              <a href="/" onClick={()=>{setValue("contact");}}>
                <span className="icon">
                  <i className="fa fa-id-card"></i>
                </span>
                <span className="text">Contact</span>

              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    
  );
}
