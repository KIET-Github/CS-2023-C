import React from 'react'

export default function Company() {

    const company = [
        {
            name: 'CISCO',
            ctc: '14 - 18 LPA',
        },
        {
            name: 'Chaayos',
            ctc: '12 LPA',
        },
        {
            name: 'Trilogy Innovations',
            ctc: '36 LPA',
        },
        {
            name: 'DXC Technology',
            ctc: '2.3 LPA'
        },
        {
            name: 'TravClan',
            ctc: '10 LPA',
        },
        {
            name: 'InfoEdge',
            ctc: '10LPA',
        },
        {
            name: 'ION Group',
            ctc: '14.10 LPA',
        },
        {
            name: 'Infosys',
            ctc: '3 LPA, 6 LPA, 9.5 LPA',
        },
        {
            name: ' Cognizant',
            ctc: '4 LPA'
        },
        {
            name: 'Gemini Solutions',
            ctc: '7.2 - 8 LPA',
        },
        {
            name: 'SimplifyVMS',
            ctc: '6 LPA',
        },
        {
            name: 'Accenture',
            ctc: '4.5 LPA and 6.5 LPA',
        },
        {
            name: 'Amantya Technology',
            ctc: '5.5 LPA',
        },
        {
            name: 'Hyundai MOBIS',
            ctc: '4.5 LPA',
        },
        {
            name: 'IBM',
            ctc: '11 LPA',
        },
        {
            name: 'Interra Systems',
            ctc: '12 LPA',
        },
        {
            name: 'Tech Mahindra',
            ctc:'3.25 LPA and 5.5 LPA',
        },
        {
            name: 'Sopra Banking Software',
            ctc: '8.5 LPA',
        },
        {
            name: 'Consultadd',
            ctc: '5 LPA, 7 LPA , 10 LPA and 12 LPA',
        },
        {
            name:'FedX India',
            ctc: 'upto 20 LPA',
        },
        {
            name:'MAQ Software',
            ctc: '7.5 LPA',
        },
        {
            name:'PPL Work',
            ctc: '10 LPA',
        },
        {
            name:'KiwiTech',
            ctc: '3-4 LPA',
        },
        {
            name:'JSW ',
            ctc: '8.5 LPA',
        },
        {
            name:'Jaro Education',
            ctc: '6.6 LPA',
        },
        {
            name:'HealthKart',
            ctc: '12 LPA',
        },
        {
            name:'Wiley Edge',
            ctc: '9 LPA',
        }
    ];

  return (
    <div>Company</div>
  )
}
