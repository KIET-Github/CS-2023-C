import React,{useState} from 'react'
import Sidenavbar from '../sideNavbar/sidenavbar';
import About from '../About/About';
import Recruitment from '../Recruitment/Recruitment';
import MainCon from '../MainCon/MainCon';
import Contact from '../Contact/Contact'

export default function MainContent () {

  const[state,setState] = useState("contact");
  function setParentValue(value){
    setState(value)
  }

  return (
    <div><br/><br/>
        <Sidenavbar setValue = {setParentValue} />
        {state === "maincon" && <MainCon/>};
        {state === "about" && <About/>};
        {state === "recruitment" && <Recruitment/>}
        {state === "contact" && <Contact/> }
    </div>
  );
}
 